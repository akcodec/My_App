import 'package:flutter/material.dart';

class MyRoutes{
  static String loginRoute="/login";
  static String homeRoute="/home";
  static String dashRoute="/dashboard";
}